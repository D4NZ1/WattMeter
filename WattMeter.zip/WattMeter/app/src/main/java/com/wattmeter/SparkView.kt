package com.wattmeter

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

class SparkView(ctx: Context) : View(ctx) {
    private val vals = FloatArray(60)
    private var n = 0
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.GREEN; strokeWidth = 3f; style = Paint.Style.STROKE
    }

    fun tint(c: Int) { line.color = c }

    fun push(v: Float) {
        if (n < vals.size) {
            vals[n++] = v
        } else {
            System.arraycopy(vals, 1, vals, 0, vals.size - 1)
            vals[vals.size - 1] = v
        }
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        if (n < 2) return
        var mx = 0.5f
        for (i in 0 until n) if (vals[i] > mx) mx = vals[i]
        val w = width.toFloat()
        val h = height.toFloat()
        val path = Path()
        for (i in 0 until n) {
            val x = w * i / (vals.size - 1)
            val y = h - h * vals[i] / mx
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, line)
    }
}
