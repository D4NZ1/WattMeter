package com.wattmeter

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class WattTile : TileService() {

    private fun update() {
        val t = qsTile ?: return
        t.state = if (Store.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "WattMeter"
        t.updateTile()
    }

    override fun onStartListening() = update()

    override fun onClick() {
        if (Store.running) {
            stopService(Intent(this, OverlayService::class.java))
        } else if (Settings.canDrawOverlays(this)) {
            startForegroundService(Intent(this, OverlayService::class.java))
        } else {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(
                    PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE)
                )
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(i)
            }
        }
        Handler(Looper.getMainLooper()).postDelayed({ update() }, 600)
    }
}
