package com.wattmeter

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuHelper {

    @Volatile var lastError = ""

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        running() && !Shizuku.isPreV11() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun request() {
        try { Shizuku.requestPermission(100) } catch (e: Throwable) { }
    }

    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
    }

    /** Executa um comando no shell (uid shell) via Shizuku e devolve o stdout. */
    fun exec(cmd: String): String = try {
        val p = newProcess.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Throwable) { lastError = e.toString(); "" }
}
