package com.wattmeter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var tv: TextView
    private lateinit var tv2: TextView
    private lateinit var lp: WindowManager.LayoutParams
    private var compact = false
    private lateinit var spark: SparkView
    private lateinit var root: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private var lastEventTs = System.currentTimeMillis() - 5000
    private var lastTick = System.currentTimeMillis()
    private var fgPkg: String? = null
    private val catCache = HashMap<String, Boolean>()

    private val tick = object : Runnable {
        override fun run() {
            try { step() } catch (e: Exception) { }
            h.postDelayed(this, 1000)
        }
    }

    private fun updateForeground(now: Long) {
        try {
            val usm = getSystemService(UsageStatsManager::class.java)
            val ev = usm.queryEvents(lastEventTs, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) fgPkg = e.packageName
            }
            lastEventTs = now - 1000
        } catch (e: SecurityException) { }
    }

    private fun isGame(pkg: String): Boolean {
        if (pkg in Store.extraGames(this)) return true
        return catCache.getOrPut(pkg) {
            try {
                packageManager.getApplicationInfo(pkg, 0).category == ApplicationInfo.CATEGORY_GAME
            } catch (e: Exception) { false }
        }
    }

    private fun labelOf(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun endSession(s: PowerSample, now: Long) {
        val c = Store.current ?: return
        c.end = now
        c.endPct = s.percent
        if (c.end - c.start >= 30_000 && c.n > 0) Store.save(this, c)
        Store.current = null
    }

    private fun step() {
        val now = System.currentTimeMillis()
        val dt = (now - lastTick) / 1000.0
        lastTick = now
        val s = Power.read(this)
        Store.last = s
        spark.push(s.watts.toFloat())
        updateForeground(now)

        val pkg = fgPkg
        val game = pkg != null && pkg != packageName && isGame(pkg)
        val c0 = Store.current
        if (c0 != null && (!game || c0.pkg != pkg)) endSession(s, now)
        if (game && Store.current == null) {
            Store.current = Session(pkg!!, labelOf(pkg), now, s.percent)
        }

        val c = Store.current
        if (c != null) {
            if (s.charging) {
                c.charged = true
            } else {
                c.sumW += s.watts; c.n++
                if (s.watts > c.maxW) c.maxW = s.watts
                if (s.tempC > c.maxTemp) c.maxTemp = s.tempC
                c.mwh += s.watts * dt * 1000.0 / 3600.0
                c.endPct = s.percent
            }
        }

        val color = when {
            s.watts < 3.0 -> 0xFF4CAF50.toInt()
            s.watts < 6.0 -> 0xFFFFC107.toInt()
            else -> 0xFFF44336.toInt()
        }
        tv.setTextColor(color)
        spark.tint(color)
        tv.text = if (s.charging) "%.1f W ⚡".format(s.watts) else "%.1f W".format(s.watts)
        tv2.text = when {
            s.charging -> "Carregando: leitura imprecisa"
            c != null && c.n > 0 -> "${c.label}\nMédia %.1f W · %.0f°C".format(c.avgW, s.tempC)
            else -> "Nenhum jogo detectado\n%.0f°C".format(s.tempC)
        }
    }

    private fun applyCompact() {
        val v = if (compact) android.view.View.GONE else android.view.View.VISIBLE
        tv2.visibility = v
        spark.visibility = v
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "watts"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(
                NotificationChannel(ch, "WattMeter", NotificationManager.IMPORTANCE_LOW)
            )
        startForeground(
            1,
            Notification.Builder(this, ch)
                .setContentTitle("WattMeter ativo")
                .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
                .build()
        )
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val prefs = getSharedPreferences("wm", MODE_PRIVATE)
        compact = prefs.getBoolean("compact", false)
        tv = TextView(this).apply { textSize = 22f; setTypeface(typeface, android.graphics.Typeface.BOLD) }
        tv2 = TextView(this).apply { textSize = 11f; setTextColor(Color.WHITE) }
        spark = SparkView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xB0000000.toInt())
            setPadding(20, 10, 20, 10)
            addView(tv)
            addView(tv2)
            addView(spark, LinearLayout.LayoutParams((130 * d).toInt(), (32 * d).toInt()))
        }
        applyCompact()
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("ox", 20); y = prefs.getInt("oy", 60)
        }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - downX).toInt()
                    val my = (e.rawY - downY).toInt()
                    if (Math.abs(mx) > 12 || Math.abs(my) > 12) moved = true
                    if (moved) {
                        lp.x = startX + mx; lp.y = startY + my
                        wm.updateViewLayout(root, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.edit().putInt("ox", lp.x).putInt("oy", lp.y).apply()
                    } else {
                        compact = !compact
                        prefs.edit().putBoolean("compact", compact).apply()
                        applyCompact()
                        wm.updateViewLayout(root, lp)
                    }
                    true
                }
                else -> false
            }
        }
        wm.addView(root, lp)
        Store.running = true
        h.post(tick)
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        Store.last?.let { endSession(it, System.currentTimeMillis()) }
        Store.running = false
        wm.removeView(root)
        super.onDestroy()
    }
}
