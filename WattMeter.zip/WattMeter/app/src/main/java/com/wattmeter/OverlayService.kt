package com.wattmeter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var tv: TextView
    private val h = Handler(Looper.getMainLooper())

    private var sum = 0.0
    private var count = 0
    private var max = 0.0

    private val tick = object : Runnable {
        override fun run() {
            val s = Power.read(this@OverlayService)
            if (!s.charging) {
                sum += s.watts; count++
                if (s.watts > max) max = s.watts
            }
            val avg = if (count > 0) sum / count else 0.0
            tv.text = if (s.charging)
                "%.2f W (carregando)\n%d%% %.0f°C".format(s.watts, s.percent, s.tempC)
            else
                "%.2f W\nméd %.2f  máx %.2f\n%.0f mA  %d%%  %.0f°C"
                    .format(s.watts, avg, max, s.milliamps, s.percent, s.tempC)
            h.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "watts"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(
                NotificationChannel(ch, "WattMeter", NotificationManager.IMPORTANCE_LOW)
            )
        startForeground(
            1,
            Notification.Builder(this, ch)
                .setContentTitle("WattMeter ativo")
                .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
                .build()
        )

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tv = TextView(this).apply {
            setTextColor(Color.GREEN)
            textSize = 12f
            setBackgroundColor(0x99000000.toInt())
            setPadding(16, 8, 16, 8)
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 60 }
        wm.addView(tv, p)
        h.post(tick)
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        wm.removeView(tv)
        super.onDestroy()
    }
}
