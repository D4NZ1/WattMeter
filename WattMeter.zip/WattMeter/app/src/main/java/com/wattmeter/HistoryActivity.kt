package com.wattmeter

import android.app.Activity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : Activity() {

    private lateinit var list: ListView
    private lateinit var empty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        list = ListView(this)
        empty = TextView(this).apply { text = "Nenhuma sessão ainda.\nJogue com o overlay ativo (mín. 30 s)."; textSize = 16f }
        val clear = Button(this).apply {
            text = "Limpar histórico"
            setOnClickListener { Store.clear(this@HistoryActivity); render() }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 96, 32, 32)
            addView(empty)
            addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(clear)
        })
        render()
    }

    private fun render() {
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        val all = Store.load(this)
        val summary = all.groupBy { it.pkg }.map { (_, l) ->
            val n = l.sumOf { it.n }
            val avg = if (n > 0) l.sumOf { it.sumW } / n else 0.0
            val min = l.sumOf { it.end - it.start } / 60000.0
            val wh = l.sumOf { it.mwh } / 1000.0
            Triple(l.first().label, wh,
                "${l.first().label}\n${l.size} sessões · %.0f min · méd %.1f W · %.2f Wh".format(min, avg, wh))
        }.sortedByDescending { it.second }.map { it.third }
        val sessions = all.map {
            val min = (it.end - it.start) / 60000.0
            "${it.label}\n${fmt.format(Date(it.start))} · %.0f min\n".format(min) +
                    "méd %.1f W · máx %.1f W · %.2f Wh".format(it.avgW, it.maxW, it.mwh / 1000.0) +
                    (if (it.fpsN > 0) " · %.0f FPS".format(it.fpsSum / it.fpsN) else "") + "\n" +
                    "bateria %d%% → %d%% · máx %.0f°C".format(it.startPct, it.endPct, it.maxTemp) +
                    if (it.charged) "\n⚠ houve carregamento" else ""
        }
        val items = if (all.isEmpty()) emptyList()
            else listOf("— POR JOGO —") + summary + listOf("— SESSÕES —") + sessions
        empty.visibility = if (items.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
    }
}
