package com.wattmeter

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Session(
    val pkg: String,
    val label: String,
    val start: Long,
    val startPct: Int,
    var end: Long = 0,
    var sumW: Double = 0.0,
    var n: Int = 0,
    var maxW: Double = 0.0,
    var mwh: Double = 0.0,
    var endPct: Int = 0,
    var maxTemp: Double = 0.0,
    var charged: Boolean = false,
    var fpsSum: Double = 0.0,
    var fpsN: Int = 0
) {
    val avgW: Double get() = if (n > 0) sumW / n else 0.0
}

object Store {
    @Volatile var current: Session? = null
    @Volatile var running = false
    @Volatile var last: PowerSample? = null

    private fun prefs(c: Context) = c.getSharedPreferences("wm", Context.MODE_PRIVATE)

    fun extraGames(c: Context): Set<String> =
        prefs(c).getStringSet("games", emptySet()) ?: emptySet()

    fun setExtraGames(c: Context, s: Set<String>) =
        prefs(c).edit().putStringSet("games", HashSet(s)).apply()

    fun load(c: Context): List<Session> {
        val out = ArrayList<Session>()
        try {
            val a = JSONArray(prefs(c).getString("sessions", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Session(
                    o.getString("pkg"), o.getString("label"), o.getLong("start"), o.getInt("sp"),
                    o.getLong("end"), o.getDouble("sum"), o.getInt("n"), o.getDouble("max"),
                    o.getDouble("mwh"), o.getInt("ep"), o.getDouble("t"), o.optBoolean("ch"), o.optDouble("fs", 0.0), o.optInt("fn", 0)
                ))
            }
        } catch (e: Exception) { }
        return out
    }

    fun save(c: Context, s: Session) {
        val list = ArrayList(load(c)); list.add(0, s)
        val a = JSONArray()
        for (x in list.take(200)) a.put(JSONObject()
            .put("pkg", x.pkg).put("label", x.label).put("start", x.start).put("sp", x.startPct)
            .put("end", x.end).put("sum", x.sumW).put("n", x.n).put("max", x.maxW)
            .put("mwh", x.mwh).put("ep", x.endPct).put("t", x.maxTemp).put("ch", x.charged).put("fs", x.fpsSum).put("fn", x.fpsN))
        prefs(c).edit().putString("sessions", a.toString()).apply()
    }

    fun clear(c: Context) = prefs(c).edit().remove("sessions").apply()
}
