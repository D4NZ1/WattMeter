package com.wattmeter

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

data class PowerSample(
    val watts: Double,
    val milliamps: Double,
    val volts: Double,
    val tempC: Double,
    val percent: Int,
    val charging: Boolean
)

object Power {
    fun read(ctx: Context): PowerSample {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        var cur = Math.abs(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)).toDouble()
        if (cur > 20000) cur /= 1000.0 // µA -> mA

        val mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val volts = if (mv > 100) mv / 1000.0 else mv.toDouble() // alguns aparelhos já reportam em V
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        return PowerSample(
            watts = (cur / 1000.0) * volts,
            milliamps = cur,
            volts = volts,
            tempC = temp,
            percent = if (scale > 0) level * 100 / scale else level,
            charging = charging
        )
    }
}
