package com.wattmeter

import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Mede FPS do app em primeiro plano lendo `dumpsys SurfaceFlinger --latency` via Shizuku. */
object FpsMeter {
    /** -1 = indisponível */
    @Volatile var fps = -1f

    private var layer: String? = null
    private var layerPkg: String? = null
    private var lastTs = 0L
    private val busy = AtomicBoolean(false)
    private val exec = Executors.newSingleThreadExecutor()

    fun poll(pkg: String?) {
        if (pkg == null || !ShizukuHelper.granted()) {
            fps = -1f; layer = null; layerPkg = null; lastTs = 0L
            return
        }
        if (!busy.compareAndSet(false, true)) return
        exec.execute {
            try { doPoll(pkg) } catch (e: Throwable) { fps = -1f } finally { busy.set(false) }
        }
    }

    private fun findLayer(pkg: String): String? {
        val list = ShizukuHelper.exec("dumpsys SurfaceFlinger --list").lines()
            .map { it.trim() }
            .filter { it.contains("$pkg/") && !it.contains("Background") }
        fun rank(s: String) = when {
            s.contains("SurfaceView") && s.contains("BLAST") -> 0
            s.contains("SurfaceView") -> 1
            else -> 2
        }
        val best = list.minOfOrNull { rank(it) } ?: return null
        return list.last { rank(it) == best }
    }

    private fun doPoll(pkg: String) {
        if (layerPkg != pkg) { layer = null; lastTs = 0L; layerPkg = pkg }
        if (layer == null) layer = findLayer(pkg)
        val l = layer
        if (l == null) { fps = -1f; return }

        val out = ShizukuHelper.exec(
            "dumpsys SurfaceFlinger --latency '" + l.replace("'", "'\\''") + "'"
        )
        val ts = ArrayList<Long>()
        for (line in out.lineSequence().drop(1)) {
            val p = line.trim().split(Regex("\\s+"))
            if (p.size >= 3) {
                val t = p[1].toLongOrNull() ?: continue
                if (t > 0 && t < Long.MAX_VALUE / 2) ts.add(t)
            }
        }
        if (ts.isEmpty()) { layer = null; fps = -1f; return }

        val fresh = ts.filter { it > lastTs }
        if (fresh.isEmpty()) { fps = 0f; return }
        val maxT = fresh.max()
        val minT = if (lastTs > 0) lastTs else fresh.min()
        val span = (maxT - minT) / 1e9
        if (span > 0.05) fps = (fresh.size / span).toFloat().coerceAtMost(240f)
        lastTs = maxT
    }
}
