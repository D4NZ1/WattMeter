package com.wattmeter

import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Mede FPS do app em primeiro plano lendo `dumpsys SurfaceFlinger --latency` via Shizuku. */
object FpsMeter {
    /** -1 = indisponível */
    @Volatile var fps = -1f
    /** Último diagnóstico de um jogo em primeiro plano (aparece na tela principal). */
    @Volatile var debug = "Nenhum jogo medido ainda."

    private var layer: String? = null
    private var layerPkg: String? = null
    private var lastTs = 0L
    private val busy = AtomicBoolean(false)
    private val exec = Executors.newSingleThreadExecutor()
    private val nameRx = Regex("""\{[0-9a-fA-F]+ (.+?)(?: parentId=|\}$)""")

    fun poll(pkg: String?) {
        if (pkg == null) {
            fps = -1f; layer = null; layerPkg = null; lastTs = 0L
            return
        }
        if (!ShizukuHelper.granted()) {
            fps = -1f
            debug = "Jogo: $pkg\nShizuku sem permissão ou parado."
            return
        }
        if (!busy.compareAndSet(false, true)) return
        exec.execute {
            try { doPoll(pkg) } catch (e: Throwable) {
                fps = -1f; debug = "Jogo: $pkg\nErro: $e"
            } finally { busy.set(false) }
        }
    }

    /** Linhas do --list podem vir como "RequestedLayerState{hash NOME parentId=..}" (Android 15). */
    private fun clean(line: String): String = nameRx.find(line)?.groupValues?.get(1) ?: line

    private fun rank(s: String) = when {
        s.contains("SurfaceView") && s.contains("BLAST") -> 0
        s.contains("SurfaceView") -> 1
        else -> 2
    }

    private fun candidates(pkg: String): List<String> {
        val all = ShizukuHelper.exec("dumpsys SurfaceFlinger --list").lines()
            .map { it.trim() }.filter { it.isNotEmpty() }
        return all.filter { it.contains(pkg) && !it.contains("Background") }
            .map { clean(it) }.distinct().sortedBy { rank(it) }.take(6)
    }

    private fun latency(name: String): List<Long> {
        val out = ShizukuHelper.exec(
            "dumpsys SurfaceFlinger --latency '" + name.replace("'", "'\\''") + "'"
        )
        val ts = ArrayList<Long>()
        for (line in out.lineSequence().drop(1)) {
            val p = line.trim().split(Regex("\\s+"))
            if (p.size >= 3) {
                val t = p[1].toLongOrNull() ?: continue
                if (t > 0 && t < Long.MAX_VALUE / 2) ts.add(t)
            }
        }
        return ts
    }

    private fun doPoll(pkg: String) {
        if (layerPkg != pkg) { layer = null; lastTs = 0L; layerPkg = pkg }

        var ts: List<Long> = emptyList()
        val l0 = layer
        if (l0 != null) ts = latency(l0)

        if (ts.size < 2) {
            layer = null
            val cands = candidates(pkg)
            if (cands.isEmpty()) {
                fps = -1f
                debug = "Jogo: $pkg\nNenhuma camada encontrada (${ShizukuHelper.lastError.ifEmpty { "lista sem o pacote" }})"
                return
            }
            for (c in cands) {
                for (v in listOf(c, c.replace(Regex("#\\d+$"), "")).distinct()) {
                    val t = latency(v)
                    if (t.size >= 2) { layer = v; ts = t; break }
                }
                if (layer != null) break
            }
            if (layer == null) {
                fps = -1f
                debug = "Jogo: $pkg\nTestei ${cands.size} camadas, nenhuma com frames.\n1ª: ${cands[0]}"
                return
            }
            lastTs = 0L
        }

        val fresh = ts.filter { it > lastTs }
        if (fresh.isEmpty()) {
            fps = 0f
            debug = "Jogo: $pkg\nCamada: $layer\namostras ${ts.size}, nenhuma nova → 0 FPS"
            return
        }
        val maxT = fresh.max()
        val minT = if (lastTs > 0) lastTs else fresh.min()
        val span = (maxT - minT) / 1e9
        if (span > 0.05) fps = (fresh.size / span).toFloat().coerceAtMost(240f)
        lastTs = maxT
        debug = "Jogo: $pkg\nCamada: $layer\namostras ${ts.size}, novas ${fresh.size} → %.1f FPS".format(fps)
    }
}
