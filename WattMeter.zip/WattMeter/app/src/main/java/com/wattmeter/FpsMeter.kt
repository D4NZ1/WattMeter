package com.wattmeter

import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Mede FPS do app em primeiro plano lendo `dumpsys SurfaceFlinger --latency` via Shizuku. */
object FpsMeter {
    /** -1 = indisponível */
    @Volatile var fps = -1f
    /** Último diagnóstico de um jogo em primeiro plano (aparece na tela principal). */
    @Volatile var debug = "Nenhum jogo medido ainda."

    private var layer: String? = null
    private var layerPkg: String? = null
    private var lastTs = 0L
    private val busy = AtomicBoolean(false)
    private val exec = Executors.newSingleThreadExecutor()

    fun poll(pkg: String?) {
        if (pkg == null) {
            fps = -1f; layer = null; layerPkg = null; lastTs = 0L
            return
        }
        if (!ShizukuHelper.granted()) {
            fps = -1f
            debug = "Jogo: $pkg\nShizuku sem permissão ou parado."
            return
        }
        if (!busy.compareAndSet(false, true)) return
        exec.execute {
            try { doPoll(pkg) } catch (e: Throwable) {
                fps = -1f; debug = "Jogo: $pkg\nErro: $e"
            } finally { busy.set(false) }
        }
    }

    private fun findLayer(pkg: String): Pair<String?, String> {
        val all = ShizukuHelper.exec("dumpsys SurfaceFlinger --list").lines().map { it.trim() }
            .filter { it.isNotEmpty() }
        if (all.isEmpty()) return null to "lista vazia (${ShizukuHelper.lastError.ifEmpty { "sem erro" }})"
        var list = all.filter { it.contains("$pkg/") && !it.contains("Background") }
        if (list.isEmpty()) list = all.filter { it.contains(pkg) && !it.contains("Background") }
        if (list.isEmpty()) {
            return null to "nenhuma camada com o pacote (total ${all.size}); ex.: ${all.take(3).joinToString(" | ")}"
        }
        fun rank(s: String) = when {
            s.contains("SurfaceView") && s.contains("BLAST") -> 0
            s.contains("SurfaceView") -> 1
            else -> 2
        }
        val best = list.minOf { rank(it) }
        return list.last { rank(it) == best } to "ok (${list.size} candidatas)"
    }

    private fun doPoll(pkg: String) {
        if (layerPkg != pkg) { layer = null; lastTs = 0L; layerPkg = pkg }
        var info = ""
        if (layer == null) {
            val (l, i) = findLayer(pkg)
            layer = l; info = i
        }
        val l = layer
        if (l == null) { fps = -1f; debug = "Jogo: $pkg\nCamada: $info"; return }

        val out = ShizukuHelper.exec(
            "dumpsys SurfaceFlinger --latency '" + l.replace("'", "'\\''") + "'"
        )
        val ts = ArrayList<Long>()
        for (line in out.lineSequence().drop(1)) {
            val p = line.trim().split(Regex("\\s+"))
            if (p.size >= 3) {
                val t = p[1].toLongOrNull() ?: continue
                if (t > 0 && t < Long.MAX_VALUE / 2) ts.add(t)
            }
        }
        if (ts.isEmpty()) {
            debug = "Jogo: $pkg\nCamada: $l\nlatency sem dados (saída: ${out.take(80).replace("\n", " ")})"
            layer = null; fps = -1f
            return
        }

        val fresh = ts.filter { it > lastTs }
        if (fresh.isEmpty()) {
            fps = 0f
            debug = "Jogo: $pkg\nCamada: $l\namostras ${ts.size}, nenhuma nova → 0 FPS"
            return
        }
        val maxT = fresh.max()
        val minT = if (lastTs > 0) lastTs else fresh.min()
        val span = (maxT - minT) / 1e9
        if (span > 0.05) fps = (fresh.size / span).toFloat().coerceAtMost(240f)
        lastTs = maxT
        debug = "Jogo: $pkg\nCamada: $l\namostras ${ts.size}, novas ${fresh.size} → %.1f FPS".format(fps)
    }
}
