package com.wattmeter

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        info = TextView(this).apply { textSize = 16f }
        val start = Button(this).apply {
            text = "Iniciar overlay"
            setOnClickListener { startOverlay() }
        }
        val stop = Button(this).apply {
            text = "Parar overlay"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            addView(info); addView(start); addView(stop)
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val s = Power.read(this)
        info.text = ("Agora: %.2f W (%.0f mA, %.2f V)\n%s\n\n" +
                "Inicie o overlay e abra o jogo. Meça sem carregador.")
            .format(s.watts, s.milliamps, s.volts,
                if (s.charging) "⚠ Carregando: leitura imprecisa" else "Na bateria")
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            startForegroundService(Intent(this, OverlayService::class.java))
        }
    }
}
