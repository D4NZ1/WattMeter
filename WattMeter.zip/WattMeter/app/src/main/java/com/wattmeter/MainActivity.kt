package com.wattmeter

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var big: TextView
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var fpsBtn: Button
    private val h = Handler(Looper.getMainLooper())

    private val refresh = object : Runnable {
        override fun run() {
            val s = Power.read(this@MainActivity)
            big.text = "%.1f W".format(s.watts)
            val c = Store.current
            status.text = when {
                !Store.running -> "Overlay parado"
                c != null -> "Jogo: ${c.label}\nmédia %.1f W · %.2f Wh".format(c.avgW, c.mwh / 1000.0)
                else -> "Overlay ativo · nenhum jogo detectado"
            } + (if (s.charging) "\n⚠ Carregando: leitura imprecisa" else "") +
                (if (!s.charging && s.mahLeft > 0 && s.milliamps > 50)
                    "\n≈ %.1f h de bateria nesse consumo".format(s.mahLeft / s.milliamps) else "")
            toggle.text = if (Store.running) "Parar" else "Iniciar"
            fpsBtn.text = when {
                !ShizukuHelper.running() -> "FPS: abrir Shizuku"
                !ShizukuHelper.granted() -> "FPS: conceder permissão"
                else -> "FPS: ativo ✓"
            }
            h.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        big = TextView(this).apply { textSize = 56f; gravity = Gravity.CENTER }
        status = TextView(this).apply { textSize = 15f; gravity = Gravity.CENTER }
        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        fpsBtn = Button(this).apply {
            setOnClickListener {
                when {
                    !ShizukuHelper.running() -> {
                        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                        if (i != null) startActivity(i)
                        else android.widget.Toast.makeText(this@MainActivity,
                            "Instale e inicie o Shizuku", android.widget.Toast.LENGTH_LONG).show()
                    }
                    !ShizukuHelper.granted() -> ShizukuHelper.request()
                }
            }
        }
        val games = Button(this).apply {
            text = "Escolher jogos"
            setOnClickListener { pickGames() }
        }
        val hist = Button(this).apply {
            text = "Histórico"
            setOnClickListener { startActivity(Intent(this@MainActivity, HistoryActivity::class.java)) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
            addView(big); addView(status); addView(toggle); addView(fpsBtn); addView(games); addView(hist)
            addView(TextView(this@MainActivity).apply {
                textSize = 13f
                setPadding(0, 48, 0, 0)
                text = "Como ler o overlay:\n" +
                    "• Verde: consumo baixo (até 3 W)\n" +
                    "• Amarelo: médio (3 a 6 W)\n" +
                    "• Vermelho: alto (acima de 6 W)\n" +
                    "• Arraste para mover.\n" +
                    "• Toque para recolher/expandir."
            })
        })
    }

    override fun onResume() { super.onResume(); h.post(refresh) }
    override fun onPause() { super.onPause(); h.removeCallbacks(refresh) }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(AppOpsManager::class.java)
        @Suppress("DEPRECATION")
        val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun onToggle() {
        if (Store.running) {
            stopService(Intent(this, OverlayService::class.java))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else if (!hasUsageAccess()) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        } else {
            startForegroundService(Intent(this, OverlayService::class.java))
        }
    }

    private fun pickGames() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val sel = Store.extraGames(this)
        val checked = BooleanArray(apps.size) { apps[it].first in sel }
        AlertDialog.Builder(this)
            .setTitle("Quais apps são jogos?")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, on -> checked[i] = on }
            .setPositiveButton("Salvar") { _, _ ->
                Store.setExtraGames(this, apps.indices.filter { checked[it] }.map { apps[it].first }.toSet())
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
